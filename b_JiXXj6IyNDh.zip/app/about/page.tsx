import { Card, CardContent } from "@/components/ui/card"
import { Target, Eye, Heart, Lightbulb } from "lucide-react"

const team = [
  {
    name: "陈志明",
    role: "创办人兼行政总裁",
    bio: "拥有超过20年科技行业经验，曾任职多家国际知名科技企业高管。",
    initials: "陈",
  },
  {
    name: "李慧琳",
    role: "技术总监",
    bio: "香港科技大学博士，专注于人工智能及机器学习研究超过15年。",
    initials: "李",
  },
  {
    name: "黄伟业",
    role: "营运总监",
    bio: "资深项目管理专家，成功交付超过200个大型企业级项目。",
    initials: "黄",
  },
  {
    name: "张美玲",
    role: "客户成功总监",
    bio: "专注于客户关系管理，致力于为客户创造长期价值。",
    initials: "张",
  },
]

const values = [
  {
    icon: Target,
    title: "使命",
    description: "通过创新科技，赋能企业实现数字化转型，助力香港及大湾区企业在全球市场中保持竞争力。",
  },
  {
    icon: Eye,
    title: "愿景",
    description: "成为亚太区最受信赖的数字化转型合作伙伴，引领企业科技创新浪潮。",
  },
  {
    icon: Heart,
    title: "核心价值",
    description: "诚信为本、客户至上、追求卓越、持续创新、团队协作。",
  },
  {
    icon: Lightbulb,
    title: "创新理念",
    description: "拥抱变化，不断探索前沿技术，为客户提供最具前瞻性的解决方案。",
  },
]

const milestones = [
  { year: "2009", event: "睿智科技于香港成立" },
  { year: "2012", event: "获得首个金融行业大型项目" },
  { year: "2015", event: "团队扩展至50人，设立深圳研发中心" },
  { year: "2018", event: "推出自主研发的企业级云平台" },
  { year: "2021", event: "获得ISO 27001资讯安全认证" },
  { year: "2024", event: "成立人工智能创新实验室" },
]

export default function AboutPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-primary text-primary-foreground py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="text-accent font-medium mb-4">关于睿智科技</p>
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl text-balance">
              以科技驱动创新，以服务创造价值
            </h1>
            <p className="mt-6 text-lg leading-relaxed opacity-90">
              睿智科技成立于2009年，是香港领先的数字化转型解决方案提供商。我们汇聚业界精英，凭借深厚的技术实力和丰富的行业经验，为超过500家企业客户提供优质的科技服务。
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Values */}
      <section className="py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              使命与愿景
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              我们坚守核心价值观，以客户为中心，追求卓越品质。
            </p>
          </div>
          
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((value) => (
              <Card key={value.title} className="bg-card">
                <CardContent className="pt-6">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <value.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">{value.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 lg:py-28 bg-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              发展历程
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              十五年来，我们与客户共同成长，不断突破创新。
            </p>
          </div>
          
          <div className="relative">
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-border -translate-x-1/2 hidden md:block" />
            <div className="space-y-8 md:space-y-0">
              {milestones.map((milestone, index) => (
                <div 
                  key={milestone.year} 
                  className={`relative md:flex md:items-center md:gap-8 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                    <Card className="inline-block bg-card">
                      <CardContent className="py-4 px-6">
                        <div className="text-2xl font-bold text-primary">{milestone.year}</div>
                        <p className="mt-1 text-sm text-muted-foreground">{milestone.event}</p>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="hidden md:flex items-center justify-center">
                    <div className="h-4 w-4 rounded-full bg-primary border-4 border-background" />
                  </div>
                  <div className="flex-1" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <p className="text-accent font-medium mb-2">核心团队</p>
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              遇见我们的领导团队
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              我们的领导团队汇聚行业精英，拥有丰富的技术背景和管理经验。
            </p>
          </div>
          
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {team.map((member) => (
              <Card key={member.name} className="bg-card text-center">
                <CardContent className="pt-8 pb-6">
                  <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-primary">{member.initials}</span>
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">{member.name}</h3>
                  <p className="text-sm text-accent font-medium mt-1">{member.role}</p>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                    {member.bio}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Company Info */}
      <section className="py-20 lg:py-28 bg-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                公司资料
              </h2>
              <p className="mt-4 text-muted-foreground leading-relaxed">
                睿智科技有限公司是在香港注册成立的科技企业，致力于为企业提供优质的数字化转型服务。
              </p>
              
              <dl className="mt-8 space-y-4">
                <div className="flex gap-4">
                  <dt className="w-32 flex-shrink-0 font-medium text-foreground">公司全称</dt>
                  <dd className="text-muted-foreground">睿智科技有限公司<br />RuiZhi Technology Limited</dd>
                </div>
                <div className="flex gap-4">
                  <dt className="w-32 flex-shrink-0 font-medium text-foreground">成立年份</dt>
                  <dd className="text-muted-foreground">2009年</dd>
                </div>
                <div className="flex gap-4">
                  <dt className="w-32 flex-shrink-0 font-medium text-foreground">注册地址</dt>
                  <dd className="text-muted-foreground">香港</dd>
                </div>
                <div className="flex gap-4">
                  <dt className="w-32 flex-shrink-0 font-medium text-foreground">员工人数</dt>
                  <dd className="text-muted-foreground">50+</dd>
                </div>
                <div className="flex gap-4">
                  <dt className="w-32 flex-shrink-0 font-medium text-foreground">认证资质</dt>
                  <dd className="text-muted-foreground">ISO 27001, ISO 9001</dd>
                </div>
              </dl>
            </div>
            
            <div className="bg-card rounded-2xl p-8 border border-border">
              <h3 className="text-xl font-semibold text-foreground mb-6">服务范围</h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <span className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="h-2 w-2 rounded-full bg-primary" />
                  </span>
                  <span className="text-muted-foreground">香港特别行政区</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="h-2 w-2 rounded-full bg-primary" />
                  </span>
                  <span className="text-muted-foreground">粤港澳大湾区</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="h-2 w-2 rounded-full bg-primary" />
                  </span>
                  <span className="text-muted-foreground">东南亚地区</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="h-2 w-2 rounded-full bg-primary" />
                  </span>
                  <span className="text-muted-foreground">中国内地主要城市</span>
                </li>
              </ul>
              
              <h3 className="text-xl font-semibold text-foreground mt-8 mb-6">行业专长</h3>
              <div className="flex flex-wrap gap-2">
                {["金融科技", "零售电商", "物流供应链", "医疗健康", "教育科技", "智慧城市"].map((industry) => (
                  <span key={industry} className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">
                    {industry}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
