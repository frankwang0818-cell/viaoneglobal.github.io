import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Mail, Phone, MapPin, Clock } from "lucide-react"
import { ContactForm } from "@/components/contact-form"

const contactInfo = [
  {
    icon: Phone,
    title: "电话咨询",
    details: ["+852 2888 1234", "+852 2888 5678"],
    description: "周一至周五 9:00-18:00",
  },
  {
    icon: Mail,
    title: "电邮联系",
    details: ["info@ruizhi.hk", "sales@ruizhi.hk"],
    description: "我们将于24小时内回覆",
  },
  {
    icon: MapPin,
    title: "办公地址",
    details: ["香港中环皇后大道中99号", "中环中心28楼"],
    description: "港铁中环站C出口步行5分钟",
  },
  {
    icon: Clock,
    title: "办公时间",
    details: ["周一至周五：9:00 - 18:00", "周六：9:00 - 13:00"],
    description: "公众假期休息",
  },
]

export default function ContactPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-primary text-primary-foreground py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="text-accent font-medium mb-4">联系我们</p>
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl text-balance">
              与我们展开对话
            </h1>
            <p className="mt-6 text-lg leading-relaxed opacity-90">
              无论您有任何业务咨询、技术问题或合作意向，我们的专业团队随时准备为您提供协助。请填写以下表格或通过其他方式联系我们。
            </p>
          </div>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-12 bg-secondary border-b border-border">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {contactInfo.map((info) => (
              <Card key={info.title} className="bg-card">
                <CardContent className="pt-6">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <info.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground">{info.title}</h3>
                  <div className="mt-2 space-y-1">
                    {info.details.map((detail, index) => (
                      <p key={index} className="text-sm text-foreground">{detail}</p>
                    ))}
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">{info.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section className="py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
            {/* Form */}
            <div>
              <Card className="bg-card">
                <CardHeader>
                  <CardTitle className="text-2xl">发送查询</CardTitle>
                  <CardDescription>
                    请填写以下表格，我们的团队将于1-2个工作天内与您联系。
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ContactForm />
                </CardContent>
              </Card>
            </div>

            {/* Map & Additional Info */}
            <div className="space-y-8">
              {/* Map placeholder */}
              <div className="aspect-video rounded-xl bg-secondary border border-border overflow-hidden">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3691.9692372908766!2d114.15384611541018!3d22.281826785325476!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x340400708c5f6e89%3A0xf8b7e1db23b50cd!2z5Lit55Ge5Lit5b-D!5e0!3m2!1szh-TW!2shk!4v1650000000000!5m2!1szh-TW!2shk"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="睿智科技办公地址"
                />
              </div>

              {/* FAQ */}
              <Card className="bg-card">
                <CardHeader>
                  <CardTitle>常见问题</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium text-foreground">咨询是否收费？</h4>
                    <p className="mt-1 text-sm text-muted-foreground">
                      首次咨询完全免费。我们的专家会详细了解您的需求，并提供初步的解决方案建议。
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground">项目周期一般多长？</h4>
                    <p className="mt-1 text-sm text-muted-foreground">
                      视乎项目复杂程度，一般为2-6个月。我们会在评估后提供详细的项目时间表。
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground">是否提供维护服务？</h4>
                    <p className="mt-1 text-sm text-muted-foreground">
                      是的，我们提供全面的项目后期维护及技术支援服务，确保系统稳定运作。
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
