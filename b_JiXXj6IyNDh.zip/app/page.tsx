import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { 
  ArrowRight, 
  Code2, 
  Cloud, 
  Brain, 
  BarChart3,
  Shield,
  Zap,
  Users,
  Award
} from "lucide-react"

const services = [
  {
    icon: Code2,
    title: "企业软件开发",
    description: "度身订造的企业级应用程式，助您实现业务流程自动化及数字化转型。",
  },
  {
    icon: Cloud,
    title: "云端服务",
    description: "安全可靠的云端基础架构解决方案，确保您的业务 24/7 稳定运作。",
  },
  {
    icon: Brain,
    title: "人工智能应用",
    description: "整合先进AI技术，为您的业务注入智能化元素，提升决策效率。",
  },
  {
    icon: BarChart3,
    title: "数据分析",
    description: "全方位数据分析及可视化服务，助您洞悉市场趋势及客户需求。",
  },
]

const stats = [
  { value: "15+", label: "年行业经验" },
  { value: "500+", label: "成功案例" },
  { value: "98%", label: "客户满意度" },
  { value: "50+", label: "专业团队" },
]

const features = [
  {
    icon: Shield,
    title: "安全可靠",
    description: "符合国际安全标准，保障您的数据安全",
  },
  {
    icon: Zap,
    title: "高效敏捷",
    description: "采用敏捷开发方法，快速响应业务需求",
  },
  {
    icon: Users,
    title: "专业团队",
    description: "经验丰富的技术专家，提供优质服务",
  },
  {
    icon: Award,
    title: "品质保证",
    description: "ISO认证品质管理，确保项目成功交付",
  },
]

export default function HomePage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-primary text-primary-foreground overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-accent rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-accent rounded-full translate-y-1/2 -translate-x-1/2" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6 py-24 lg:px-8 lg:py-32">
          <div className="max-w-2xl">
            <p className="text-accent font-medium mb-4">香港领先的科技解决方案提供商</p>
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl text-balance">
              赋能企业数字化转型
            </h1>
            <p className="mt-6 text-lg leading-relaxed opacity-90">
              睿智科技专注于为香港及大湾区企业提供全方位的数字化解决方案。从企业软件开发到云端服务，从人工智能到数据分析，我们助您把握科技机遇，引领行业未来。
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/contact">
                  免费咨询
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10" asChild>
                <Link href="/about">
                  了解更多
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-card border-b border-border">
        <div className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
          <div className="grid grid-cols-2 gap-8 lg:grid-cols-4">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl font-bold text-primary lg:text-4xl">{stat.value}</div>
                <div className="mt-2 text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-accent font-medium mb-2">我们的服务</p>
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
              全方位科技解决方案
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              我们提供一站式的技术服务，从策略规划到落地实施，全程陪伴您的数字化转型之旅。
            </p>
          </div>
          
          <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((service) => (
              <Card key={service.title} className="bg-card hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <service.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">{service.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 lg:py-28 bg-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <p className="text-accent font-medium mb-2">为何选择我们</p>
              <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
                您值得信赖的科技伙伴
              </h2>
              <p className="mt-4 text-muted-foreground leading-relaxed">
                凭借超过15年的行业经验，我们深入了解香港及大湾区企业的独特需求，提供切合本地市场的解决方案。
              </p>
              <div className="mt-10 grid gap-6 sm:grid-cols-2">
                {features.map((feature) => (
                  <div key={feature.title} className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <feature.icon className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{feature.title}</h3>
                      <p className="mt-1 text-sm text-muted-foreground">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-2xl bg-primary/5 border border-border flex items-center justify-center">
                <div className="text-center p-8">
                  <div className="text-6xl font-bold text-primary">15+</div>
                  <div className="mt-2 text-lg text-muted-foreground">年行业经验</div>
                  <div className="mt-6 text-sm text-muted-foreground">
                    服务超过500家企业客户<br />
                    横跨金融、零售、物流等多个行业
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-28 bg-primary text-primary-foreground">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl text-balance">
            准备好开启数字化转型之旅？
          </h2>
          <p className="mt-4 text-lg opacity-90 max-w-2xl mx-auto">
            立即联系我们的专业团队，获取免费咨询服务。我们将为您度身定制最适合的解决方案。
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/contact">
                立即咨询
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10" asChild>
              <a href="tel:+85228881234">
                致电 +852 2888 1234
              </a>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
