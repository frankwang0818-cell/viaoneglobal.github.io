"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Spinner } from "@/components/ui/spinner"
import { CheckCircle2 } from "lucide-react"

export function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <div className="text-center py-12">
        <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
          <CheckCircle2 className="h-8 w-8 text-green-600" />
        </div>
        <h3 className="text-xl font-semibold text-foreground">感谢您的查询</h3>
        <p className="mt-2 text-muted-foreground">
          我们已收到您的信息，将于1-2个工作天内与您联系。
        </p>
        <Button 
          variant="outline" 
          className="mt-6"
          onClick={() => setIsSubmitted(false)}
        >
          提交新查询
        </Button>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="name">姓名 *</Label>
          <Input 
            id="name" 
            name="name"
            placeholder="请输入您的姓名" 
            required 
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="company">公司名称</Label>
          <Input 
            id="company" 
            name="company"
            placeholder="请输入公司名称" 
          />
        </div>
      </div>
      
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="email">电邮地址 *</Label>
          <Input 
            id="email" 
            name="email"
            type="email" 
            placeholder="your@email.com" 
            required 
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone">联络电话</Label>
          <Input 
            id="phone" 
            name="phone"
            type="tel" 
            placeholder="+852 xxxx xxxx" 
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="service">感兴趣的服务</Label>
        <Select name="service">
          <SelectTrigger id="service">
            <SelectValue placeholder="请选择服务类型" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="software">企业软件开发</SelectItem>
            <SelectItem value="cloud">云端服务</SelectItem>
            <SelectItem value="ai">人工智能应用</SelectItem>
            <SelectItem value="data">数据分析</SelectItem>
            <SelectItem value="consulting">技术咨询</SelectItem>
            <SelectItem value="other">其他</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="budget">预算范围</Label>
        <Select name="budget">
          <SelectTrigger id="budget">
            <SelectValue placeholder="请选择预算范围" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="under50k">HK$ 50,000以下</SelectItem>
            <SelectItem value="50k-100k">HK$ 50,000 - 100,000</SelectItem>
            <SelectItem value="100k-500k">HK$ 100,000 - 500,000</SelectItem>
            <SelectItem value="500k-1m">HK$ 500,000 - 1,000,000</SelectItem>
            <SelectItem value="over1m">HK$ 1,000,000以上</SelectItem>
            <SelectItem value="undecided">待定</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="message">查询内容 *</Label>
        <Textarea 
          id="message" 
          name="message"
          placeholder="请详细描述您的需求或问题..."
          rows={5}
          required
        />
      </div>
      
      <div className="text-sm text-muted-foreground">
        <p>
          提交此表格即表示您同意我们的
          <a href="#" className="text-primary hover:underline">私隐政策</a>
          及
          <a href="#" className="text-primary hover:underline">使用条款</a>
          。
        </p>
      </div>
      
      <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
        {isSubmitting ? (
          <>
            <Spinner className="mr-2" />
            提交中...
          </>
        ) : (
          "提交查询"
        )}
      </Button>
    </form>
  )
}
