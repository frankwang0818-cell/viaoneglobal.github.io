import Link from "next/link"
import { Mail, Phone, MapPin } from "lucide-react"

const navigation = {
  solutions: [
    { name: "企业软件开发", href: "#" },
    { name: "云端服务", href: "#" },
    { name: "人工智能", href: "#" },
    { name: "数据分析", href: "#" },
  ],
  company: [
    { name: "关于我们", href: "/about" },
    { name: "联系我们", href: "/contact" },
    { name: "加入我们", href: "#" },
    { name: "新闻动态", href: "#" },
  ],
}

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="mx-auto max-w-7xl px-6 py-12 lg:px-8 lg:py-16">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary-foreground flex items-center justify-center">
                <span className="text-primary font-bold text-xl">睿</span>
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold tracking-tight">睿智科技</span>
                <span className="text-xs opacity-80 tracking-wider">RuiZhi Technology</span>
              </div>
            </div>
            <p className="mt-4 text-sm opacity-80 leading-relaxed">
              香港领先的数字化转型解决方案提供商，致力于为企业提供卓越的技术服务。
            </p>
          </div>
          
          {/* Solutions */}
          <div>
            <h3 className="text-sm font-semibold tracking-wider uppercase">解决方案</h3>
            <ul className="mt-4 space-y-3">
              {navigation.solutions.map((item) => (
                <li key={item.name}>
                  <Link href={item.href} className="text-sm opacity-80 hover:opacity-100 transition-opacity">
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Company */}
          <div>
            <h3 className="text-sm font-semibold tracking-wider uppercase">公司</h3>
            <ul className="mt-4 space-y-3">
              {navigation.company.map((item) => (
                <li key={item.name}>
                  <Link href={item.href} className="text-sm opacity-80 hover:opacity-100 transition-opacity">
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h3 className="text-sm font-semibold tracking-wider uppercase">联络我们</h3>
            <ul className="mt-4 space-y-3">
              <li>
                <a href="tel:+85228881234" className="flex items-center gap-2 text-sm opacity-80 hover:opacity-100 transition-opacity">
                  <Phone className="h-4 w-4" />
                  +852 2888 1234
                </a>
              </li>
              <li>
                <a href="mailto:info@ruizhi.hk" className="flex items-center gap-2 text-sm opacity-80 hover:opacity-100 transition-opacity">
                  <Mail className="h-4 w-4" />
                  info@ruizhi.hk
                </a>
              </li>
              <li>
                <div className="flex items-start gap-2 text-sm opacity-80">
                  <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>香港中环皇后大道中99号<br />中环中心28楼</span>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 border-t border-primary-foreground/20 pt-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <p className="text-xs opacity-60">
              &copy; {new Date().getFullYear()} 睿智科技有限公司. 版权所有.
            </p>
            <div className="flex gap-6">
              <Link href="#" className="text-xs opacity-60 hover:opacity-100 transition-opacity">
                私隐政策
              </Link>
              <Link href="#" className="text-xs opacity-60 hover:opacity-100 transition-opacity">
                使用条款
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
